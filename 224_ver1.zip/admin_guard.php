<!-- <?PHP
if(empty($_SESSION['name']))
{
    die("<script>alert('Please log in.');
         window.location.href='../index.php';/</script>
         ");
}
?> -->