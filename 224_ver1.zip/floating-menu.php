<div class="rightNav"><ul>
    <li>
        <a href="make-appointment.php" target="_blank">
            <span class="s1">
                <img class="icon" title="" src="images/make-appointment-icon.png" title="" alt="">
                <img class="icon-white" src="images/make-appointment-icon-white.png" title="" alt="">
            </span>
            <span class="s2">Make Appointment</span>
        </a>
    </li>
    <li>
        <a href="find-doctor.php" target="_blank">
            <span class="s1">
                <img class="icon" title="" src="images/find-doctor-icon.png" title="" alt="">
                <img class="icon-white" src="images/find-doctor-icon-white.png" title="" alt="">
            </span>
            <span class="s2">Find Doctor</span>
        </a>
    </li>
    <li>
        <a href="telemedicine.php" target="_blank">
            <span class="s1">
                <img class="icon" title="" src="images/telemedicine-icon.png" title="" alt="">
                <img class="icon-white" src="images/telemedicine-icon-white.png" title="" alt="">
            </span>
            <span class="s2">Telemedicine</span>
        </a>
    </li>
    <li>
        <a href="donation.php" target="_blank">
            <span class="s1">
                <img class="icon" title="" src="images/donation-icon.png" title="" alt="">
                <img class="icon-white" src="images/donation-icon-white.png" title="" alt="">
            </span>
            <span class="s2">Donation</span>
        </a>
    </li>
    <li>
        <a href="#" target="_blank">
            <span class="s1">
                <img class="icon" title="" src="images/up-icon.png" title="" alt="">
                <img class="icon-white" src="images/up-icon-white.png" title="" alt="">
            </span>
            <span class="s2"></span>
        </a>
    </li>
</div>