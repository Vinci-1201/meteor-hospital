<?php
include("connection.php");
include("header.php");
include("navigation-admin.php");
?>

<div class="banner-appointment-list">
    <div class="col-md-8 intro">
        <div class="banner-text">
            <p class="page-title">PAYMENT LIST</p>
        </div>
    </div>
</div>

<div class="container mt-4">
    <form method="post">
        <?php
        // Check if the form is submitted for batch deletion
        if (isset($_POST['delete_selected'])) {
            if (!empty($_POST['selected_payments'])) {
                $selected_payments = $_POST['selected_payments'];
                $ids = implode(',', $selected_payments); // Create a comma-separated list of selected payment IDs

                // Construct the SQL query to delete the selected records
                $delete_query = "DELETE FROM payments WHERE paymentID IN ($ids)";

                if ($mysqli->query($delete_query)) {
                    echo "<div class='alert alert-success'>Selected payments DELETED successfully.</div>";
                } else {
                    echo "<div class='alert alert-danger'>Error deleting selected payments: " . $mysqli->error . "</div>";
                }
            }
        }
        ?>
        
        <br><br>
        <table class="table table-bordered table-hover">
            <thead class="thead-dark">
                <tr>
                    <th>ID</th>
                    <th>Appointment Date</th>
                    <th>Appointment Time</th>
                    <th>Patient Name</th>
                    <th>Doctor Name</th>
                    <th>Fee</th>
                    <th>Payment Amount</th>
                    <th>Payment Date</th>
                    <th>Payment Type</th>
                    <th>Remarks</th>
                    <th colspan="3">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Step 2: Query the database to fetch payment information
                $sql = "SELECT p.paymentID, p.telemedicineID, p.amount, p.paymentDate, p.paymentType, p.remarks,
                        a.appointmentDate, a.appointmentTime, pa.patientName, d.doctorName, t.fee
                        FROM payments p
                        INNER JOIN telemedicine t ON p.telemedicineID = t.telemedicineID
                        INNER JOIN appointments a ON t.appointmentID = a.appointmentID
                        INNER JOIN patients pa ON a.patientIC = pa.patientIC
                        INNER JOIN doctors d ON a.doctorID = d.doctorID";

                $result = $mysqli->query($sql);

                if ($result) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row["paymentID"] . "</td>";
                        echo "<td>" . $row["appointmentDate"] . "</td>";
                        echo "<td>" . $row["appointmentTime"] . "</td>";
                        echo "<td>" . $row["patientName"] . "</td>";
                        echo "<td>" . $row["doctorName"] . "</td>";
                        echo "<td>" . $row["fee"] . "</td>";
                        echo "<td>" . $row["amount"] . "</td>";
                        echo "<td>" . $row["paymentDate"] . "</td>";
                        echo "<td>" . $row["paymentType"] . "</td>";
                        echo "<td>" . $row["remarks"] . "</td>";
                        // Add a checkbox for selecting records for deletion
                        echo "<td><input type='checkbox' name='selected_payments[]' value='" . $row["paymentID"] . "'></td>";
                        // Add a "Delete" link for individual record deletion
                        echo "<td><a href='delete.php?table=payments&column=paymentID&ID=" . $row["paymentID"] . "' class='btn btn-danger btn-sm'>Delete</a></td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='12' class='text-danger'>Error: " . $mysqli->error . "</td></tr>";
                }
                ?>
            </tbody>
        </table>
        <button type="submit" class="btn btn-danger" name="delete_selected">Delete Selected</button>
    </form>
</div>