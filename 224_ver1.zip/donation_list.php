<?php
include("connection.php");
include("header.php");
include("navigation-admin.php");
?>

<div class="banner-appointment-list">
    <div class="col-md-8 intro">
        <div class="banner-text">
            <p class="page-title">DONATION LIST</p>
        </div>
    </div>
</div>

<div class="container mt-4">
    <form method="post">
        <?php
        // Check if the form is submitted for batch deletion
        if (isset($_POST['delete_selected'])) {
            if (!empty($_POST['selected_donations'])) {
                $selected_donations = $_POST['selected_donations'];
                $ids = implode(',', $selected_donations); // Create a comma-separated list of selected donation IDs

                // Construct the SQL query to delete the selected records
                $delete_query = "DELETE FROM donations WHERE donationID IN ($ids)";

                if ($mysqli->query($delete_query)) {
                    echo '<div class="alert alert-success" role="alert">Selected donations DELETED successfully.</div>';
                } else {
                    echo '<div class="alert alert-danger" role="alert">Error deleting selected donations: ' . $mysqli->error . '</div>';
                }
            }
        }
        ?>
        
        <br><br>
        <table class="table table-bordered table-hover">
            <thead class="thead-dark">
                <tr>
                    <th>ID</th>
                    <th>Donor</th>
                    <th>Donor Contact</th>
                    <th>Donor Email</th>
                    <th>Amount</th>
                    <th>Payment Type</th>
                    <th>Message</th>
                    <th colspan="3">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Step 2: Query the database to fetch donation information
                $sql = "SELECT donationID, donor, donorContact, donorEmail, amount, paymentType, message FROM donations";

                $result = $mysqli->query($sql);

                if ($result) {
                    while ($row = $result->fetch_assoc()) {
                        echo '<tr>';
                        echo '<td>' . $row["donationID"] . '</td>';
                        echo '<td>' . $row["donor"] . '</td>';
                        echo '<td>' . $row["donorContact"] . '</td>';
                        echo '<td>' . $row["donorEmail"] . '</td>';
                        echo '<td>' . $row["amount"] . '</td>';
                        echo '<td>' . $row["paymentType"] . '</td>';
                        echo '<td>' . $row["message"] . '</td>';
                        // Add a checkbox for selecting records for deletion
                        echo '<td><input type="checkbox" name="selected_donations[]" value="' . $row["donationID"] . '"></td>';
                        echo '</tr>';
                    }
                } else {
                    echo '<tr><td colspan="8" class="text-danger">Error: ' . $mysqli->error . '</td></tr>';
                }
                ?>
            </tbody>
        </table>
        <button type="submit" name="delete_selected" class="btn btn-danger">Delete Selected</button>
    </form>
</div>
