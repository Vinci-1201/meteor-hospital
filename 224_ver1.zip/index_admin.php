<?PHP
// session_start();
include('header.php');
//include('floating-menu.php');
include('navigation-admin.php');
// include ("admin_guard.php");
include ("connection.php");
?>

<div class="banner-appointment-list">
        <div class="container">
            <div class="col-md-8 intro">
            <?php
            if(isset($_SESSION["name"])) {
                $name = $_SESSION["name"];
                echo "Welcome to admin part, $name!";
            } else {
                header("Location: login.php");
            } ?>
            </div>
        </div>
    </div>
</div>