<?php
include("connection.php");
include("header.php");
include("navigation-admin.php");
?>

<div class="banner-appointment-list">
    <div class="col-md-8 intro">
        <div class="banner-text">
            <p class="page-title">PAYMENT LIST</p>
        </div>
    </div>
</div>

<div class="container mt-4">
    <form method="post">
        <?php
        // Check if the form is submitted for batch deletion
        if (isset($_POST['delete_selected'])) {
            if (!empty($_POST['selected_patients'])) {
                $selected_patients = $_POST['selected_patients'];
                $icNumbers = implode("','", $selected_patients); // Create a comma-separated list of selected patient IC numbers

                // Construct the SQL query to delete the selected records
                $delete_query = "DELETE FROM patients WHERE patientIC IN ('$icNumbers')";

                if ($mysqli->query($delete_query) === TRUE) {
                    echo "Selected records DELETED successfully.";
                } else {
                    echo "Error deleting selected records: " . $mysqli->error;
                }
            }
        }
        ?>
        
        <br><br>
        <table class="table table-bordered table-hover">
            <thead class="thead-dark">
                <tr>
                    <th>ID</th>
                    <th>Medicine Names</th>
                    <th colspan="3">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Step 2: Query the database to fetch shipping information with relevant data
                $sql = "SELECT sm.shippingID, GROUP_CONCAT(m.medicineName SEPARATOR '<br>') AS medicineNames
                        FROM shipping_medicine AS sm
                        JOIN medicine AS m ON sm.medicineID = m.medicineID
                        GROUP BY sm.shippingID";

                $result = $mysqli->query($sql);

                if ($result) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row["shippingID"] . "</td>";
                        echo "<td>" . $row["medicineNames"] . "</td>";
                        echo "<td><input type='checkbox' name='selected_patients[]' value='" . $row["shippingID"] . "'></td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='3' class='text-danger'>Error: " . $mysqli->error . "</td></tr>";
                }
                ?>
            </tbody>
        </table>
        <button type="submit" class="btn btn-danger" name="delete_selected">Delete Selected</button>
    </form>
</div>

<?php
// ORIGINAL CODE
//include("connection.php");
// include("header.php");
// include("navigation-admin.php");

// Check if the form is submitted for batch deletion
// if (isset($_POST['delete_selected'])) {
//     if (!empty($_POST['selected_patients'])) {
//         $selected_patients = $_POST['selected_patients'];
//         $icNumbers = implode("','", $selected_patients); // Create a comma-separated list of selected patient IC numbers

//         // Construct the SQL query to delete the selected records
//         $delete_query = "DELETE FROM patients WHERE patientIC IN ('$icNumbers')";

//         if ($mysqli->query($delete_query) === TRUE) {
//             echo "Selected records DELETED successfully.";
//         } else {
//             echo "Error deleting selected records: " . $mysqli->error;
//         }
//     }
// }

// Step 2: Query the database to fetch shipping information with relevant data
// $sql = "SELECT sm.shippingID, GROUP_CONCAT(m.medicineName SEPARATOR '\n') AS medicineNames
//         FROM shipping_medicine AS sm
//         JOIN medicine AS m ON sm.medicineID = m.medicineID
//         GROUP BY sm.shippingID";

// $result = $mysqli->query($sql);

// if ($result) {
//     // Step 3: Display Data in a Table
//     if ($result->num_rows > 0) {
//         echo "<h1>Shipping List:</h1>";
//         echo '<form method="post">';
//         echo '<table class="table table-striped table-bordered table-hover">';
//         echo '<thead class="thead-dark">';
//         echo '<tr>';
//         echo '<th>Shipping ID</th>';
//         echo '<th>Medicine Names</th>';
//         // echo '<th>Patient Name</th>';
//         // echo '<th>Doctor Name</th>';
//         // echo '<th>Shipping Date</th>';
//         // echo '<th>Payment Status</th>';
//         echo '<th colspan=2>Action</th>';
//         echo '</tr>';
//         echo '</thead>';
//         echo '<tbody>';

//         while ($row = $result->fetch_assoc()) {
//             echo '<tr>';
//             echo '<td>' . $row["shippingID"] . '</td>';
//             echo '<td>' . nl2br($row["medicineNames"]) . '</td>';
//             // echo '<td>' . $row["patientName"] . '</td>';
//             // echo '<td>' . $row["doctorName"] . '</td>';
//             // echo '<td>' . $row["shippingDate"] . '</td>';
//             // echo '<td>' . $row["paymentStatus"] . '</td>';

//             // Add a checkbox for selecting records for deletion
//             echo '<td><input type="checkbox" name="selected_patients[]" value="' . $row["shippingID"] . '"></td>';
//             // Add an "Edit" link for individual record editing
//             echo '<td><a class="btn btn-primary" href="edit.php?id=' . $row["shippingID"] . '">Edit</a></td>';
//              // Add a "Delete" link for individual record deletion
//              echo '<td><a class="btn btn-danger" href="delete.php?table=patients&column=shippingID&IC=' . $row["shippingID"] . '">Delete</a></td>';
//             echo '</tr>';
//         }
//         echo '</tbody>';
//         echo '</table>';
//         // Add a "Delete Selected" button
//         echo '<button type="submit" name="delete_selected" class="btn btn-danger">Delete Selected</button>';
//         echo '</form>';
//     } else {
//         echo "No shipping records found.";
//     }
// } else {
//     echo "Error: " . $mysqli->error;
// }