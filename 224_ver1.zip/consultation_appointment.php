<?php
include('navigation.php'); // Include the navigation bar
include('floating-menu.php'); // Include the floating menu
include('header.php');
?>

<!DOCTYPE html>
<html lang="en">
    <body>
        <div class="banner-make-appointment">
            <div class="breadcrumb-div">
                <p>
                    <a href="index.html">HOME</a> &nbsp;&nbsp;&nbsp; > &nbsp;&nbsp;&nbsp; <a href="doctor_appointment.html">MAKE APPOINTMENT</a> &nbsp;&nbsp;&nbsp; > &nbsp;&nbsp;&nbsp; <span class="selected-page">Doctor's Appointment</span>
                </p>
            </div>
            <div class="banner-text">
                <p class="page-title">APPOINTMENT /<br> ENQUIRY</p>
                <p class="page-text">Your health is our priority. Book an <br> appointment or enquire with us today.</p>
            </div>
        </div>

        <br>
        <br>

        <!-- Progress bar -->
        <div class="progressbar">
            <div class="progress" id="progress"></div>

            <div class="progress-step" data-title="Registration Categories"></div>
            <div class="progress-step" data-title="Appointment Information"></div>
            <div class="progress-step" data-title="Select Doctor"></div>
            <div class="progress-step" data-title="Choose Date and Location"></div>
            <div class="progress-step" data-title="Review Appointment Details"></div>
            <div class="progress-step" data-title="Appointment Confirmed"></div>
        </div>

        <br>
        <br>
        <br>
        <br>

        <div class="container border rounded p-4 mt-5 container-color">
            <!-- Form Section -->
            <div class="container-form">
                <div class="formBox20210318 formBox20210318SZ" v-show="step2 == 1">
                    <ul class="list-unstyled">
                        <li class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <ion-icon name="person-circle-outline"></ion-icon>
                                    </span>
                                </div>
                                <input type="text" class="form-control" v-model="patient.PatientName" placeholder="Name">
                                &nbsp;&nbsp;&nbsp;
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <ion-icon name="card-outline"></ion-icon>
                                    </span>
                                </div>
                                <select v-model="patient.TheTypeOfPatient" class="form-control">
                                    <option value="">Payment Method</option>
                                    <option value='1'>Medical Insurance</option>
                                    <option value='0'>Self-Payment</option>
                                    <option value='2'>Medical Insurance (Out-of-Pocket)</option>
                                    <option value='3'>Medical Insurance (Special Cases)</option>
                                    <option value='4'>Public Healthcare</option>
                                </select>
                            </div>
                        </li>
                        <li class="form-group">
                            <div class="input-group dob">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <ion-icon name="transgender-outline"></ion-icon>
                                    </span>
                                </div>
                                <select v-model="patient.userGender" class="form-control">
                                    <option value="">Gender</option>
                                    <option value="M">Male</option>
                                    <option value="F">Female</option>
                                </select>
                                &nbsp;&nbsp;&nbsp;
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <ion-icon name="calendar-outline"></ion-icon>
                                    </span>
                                </div>
                                <input class="form-control" type="text" v-model="patient.Birthday" id="birthdate-input" placeholder="Date of Birth" onfocus="(this.type='date')" onblur="(this.type='text')">
                            </div>
                        </li>

                        <li class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <ion-icon name="finger-print-outline"></ion-icon>
                                    </span>
                                </div>
                                <input type="text" class="form-control" v-model="patient.PatientName" placeholder="NRIC / Passport No.">
                                &nbsp;&nbsp;&nbsp;
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <ion-icon name="call-outline"></ion-icon>
                                    </span>
                                </div>
                                <input type="text" class="form-control" v-model="patient.PhoneNumbers" placeholder="Phone Number">
                            </div>
                        </li>

                        <li class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <ion-icon name="home-outline"></ion-icon>
                                    </span>
                                </div>
                                <input type="text" class="form-control" v-model="patient.Patientaddress" placeholder="Address">
                            </div>
                        </li>

                        <li class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <ion-icon name="create-outline"></ion-icon>
                                    </span>
                                </div>
                                <textarea class="form-control" v-model="patient.issue" placeholder="Describe the issue you are facing" rows="4"></textarea>
                            </div>
                        </li>
                    </ul>
                    <div class="form-check">
                        <input name="staPopCheck1" type="checkbox" class="form-check-input" @click="checkBtn1">
                        <label class="form-check-label">
                            I have read and agreed to the 'Personal Information Protection Policy'.
                        </label>
                    </div>
                </div>
            </div>

            <div class="text-center mt-3">
                <a href="make-appointment.php">
                    <button class="btn btn-secondary" style="width: 150px;">Previous</button>
                </a>

                <a href="health-screening-2.php">
                    <button class="btn btn-success" style="width: 150px;">Next</button>
                </a>
            </div>
        </div>

        <br><br><br><br><br>
    </body>
</html>