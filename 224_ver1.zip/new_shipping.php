<?php
include("header.php");
include("connection.php");
include("navigation-admin.php");

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the form data
    $patientName = $mysqli->real_escape_string($_POST["patientName"]);
    $patientAddress = $mysqli->real_escape_string($_POST["patientAddress"]);
    $shippingDate = $mysqli->real_escape_string($_POST["shippingDate"]);
    $remark = $mysqli->real_escape_string($_POST["remark"]);

    // You may need to validate and sanitize the input data here

    // Check if any medicines were selected
    if (isset($_POST["medicines"])) {
        $selectedMedicines = $_POST["medicines"];

        // Insert the selected medicines into the database (assuming you have a separate table for shipping medicines)
        foreach ($selectedMedicines as $medicine) {
            $sql = "INSERT INTO shipping_medicines (shipping_id, medicine) VALUES (?, ?)";
            $stmt = $mysqli->prepare($sql);
            $stmt->bind_param("ss", $shippingId, $medicine);

            // You should replace $shippingId with the actual ID of the shipping record created earlier

            if ($stmt->execute()) {
                // Medicine record added successfully
            } else {
                // Handle the error if the insertion fails
                echo "Error: " . $mysqli->error;
            }

            $stmt->close();
        }
    } else {
        // Handle the case where no medicines were selected
    }
}
?>

<body>
    <form action="new_shipping.php" method="POST" enctype="multipart/form-data">
        <div class="banner-appointment-list">
            <div class="col-md-8 intro">
                <div class="banner-text">
                    <p class="page-title">Add New Shipping</p>
                </div>
            </div>
        </div>

        <div class="container mt-4">
        <form action="new_shipping.php" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="patientName">Patient Name:</label>
                <select class="form-control" name="patientName" id="patientName">
                    <!-- get options from the database and populate the select element -->
                </select>
            </div>
            <div class="form-group">
                <label for="patientAddress">Patient Address:</label>
                <input class="form-control" type="text" name="patientAddress" id="patientAddress" required>
            </div>
            <div class="form-group">
                <label for="shippingDate">Shipping Date:</label>
                <input class="form-control" type="date" name="shippingDate" id="shippingDate" required>
            </div>
            <div class="form-group">
                <label for="remark">Remark:</label>
                <textarea class="form-control" name="remark" id="remark" cols="20" rows="6"></textarea>
            </div>
            <br>
            <h5>Select Medicines:</h5>

            <!-- Get medicine options from the database and populate the checkboxes -->
            <!-- Replace "med1", "med2", and "med3" with actual medicine values -->
            <div class="form-check">
                <input class="form-check-input" type="checkbox" name="medicines[]" value="med1" id="med1">
                <label class="form-check-label" for="med1">Medicine 1</label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="checkbox" name="medicines[]" value="med2" id="med2">
                <label class="form-check-label" for="med2">Medicine 2</label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="checkbox" name="medicines[]" value="med3" id="med3">
                <label class="form-check-label" for="med3">Medicine 3</label>
            </div>
            <br>

            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
    </form>
</body>