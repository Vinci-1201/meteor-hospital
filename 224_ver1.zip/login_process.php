<?php
include ("connection.php");
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {

if (isset($_POST['IC_ID']) && isset($_POST['password']) && isset($_POST['role'])) {
    function validate($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

    $ICID = validate($_POST['IC_ID']);
    $pass = validate($_POST['password']);
    $type = validate($_POST['role']);

    if (empty($ICID) || empty($pass)) {
        header("Location: login.php?error=Username and password are required");
        exit();
    } else {
        if ($type == 'admin') {
            $table = "admins";
            $icIdColumn = "adminID";
        } else {
            $table = "patients";
            $icIdColumn = "patientIC";
        }

        $stmt = $mysqli->prepare("SELECT * FROM $table WHERE $icIdColumn = ? AND password = ?");
        $stmt->bind_param("ss", $ICID, $pass);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $row = $result->fetch_assoc();

            $_SESSION["${type}IC"] = $row[$icIdColumn];
            $_SESSION["name"] = $row["name"];
            $_SESSION["id"] = $row["id"];

            if ($type == 'admin') {
                header("Location: index_admin.php");
                exit();
            } else {
                header("Location: index_patient.php");
                exit();
            }
        } else {
            header("Location: login.php?error=Incorrect User IC/ID or password");
            exit();
        }
    }
} else {
    header("Location: login.php");
    exit();
}
}

?>